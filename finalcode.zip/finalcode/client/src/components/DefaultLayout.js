import React from "react";
import { Menu, Dropdown, Button, Space, Row, Col } from "antd";
import { Link } from 'react-router-dom'



function DefaultLayout(props) {
  const user = JSON.parse(localStorage.getItem('user'))

  return (
    <div>
      <div className="header bs1">
        <Row gutter={16} justify='center'>
          <Col lg={20} sm={24} xs={24}>
            <div className="d-flex justify-content-between">
              <h1>
                <b>
                  <img src="https://dynamic.brandcrowd.com/preview/logodraft/212ee9f0-60bb-497b-8093-9b42dc74cae6/image/large.png" width={100} />
                  <Link to="/"> <span style={{ color: 'purple' }} > Vehicle 24/7 </span></Link>
                </b>
              </h1>

              <div class="dropdown">
                <a class="btn btn-success dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                  <Button>{user.data.username}</Button>
                </a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                  <li><a class="dropdown-item" href="./">Home</a></li>
                  <li><a class="dropdown-item" href="./admin">admin</a></li>
                  <li><a class="dropdown-item" href="./UserBookings">bookings</a></li>
                  <li><a class="dropdown-item" href="./login">logout</a></li>
                </ul>
              </div>
            </div>
          </Col>
        </Row>

      </div>
      <div className="content">{props.children}</div>
      <div className="footer text-center">
        <hr />
        <a class="f1" href="/contact">CONTACT US</a>
      </div>
    </div>
  );
}



export default DefaultLayout;