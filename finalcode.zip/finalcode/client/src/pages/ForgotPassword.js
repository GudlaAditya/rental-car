import React from 'react'
import { Row, Col, Form, Input } from 'antd'
import { Link } from 'react-router-dom'
import { message } from 'antd'


function ForgotPassword() {

    function onFinish(values) {
        // console.log("password sent to your mail")
        message.success('reset password link sent to your mail')

    }

    return (

        <div className='login'>

            <Row gutter={16} className='d-flex align-items-center' >

                <Col lg={16} style={{ position: 'relative' }}>
                    <img

                        src="https://images.unsplash.com/photo-1517026575980-3e1e2dedeab4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8Y2FyfGVufDB8MHwwfGJsYWNrfA%3D%3D&auto=format&fit=crop&w=500&q=60" />

                </Col>
                <Col lg={8} className='text-left p-5'>
                    <Form layout='vertical' className='login-form p-5' onFinish={onFinish}>
                        <h1>Login</h1>
                        <hr />
                        <Form.Item name='email' label='email' rules={[{ required: true }]}>
                            <Input />
                        </Form.Item>


                        <button className='btn1 mt-2'>send mail</button>

                        <hr />
                        <Link to='/login'> click here to login</Link>

                        <hr />

                        <Link to='/register'>Click Here to Register</Link>

                    </Form>
                </Col>

            </Row>

        </div>


    )
}
export default ForgotPassword;