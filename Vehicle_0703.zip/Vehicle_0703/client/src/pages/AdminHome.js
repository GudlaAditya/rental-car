import React from 'react'

function AdminHome() {
  return (
    <h3> AdminHome</h3>
  )
}

export default AdminHome